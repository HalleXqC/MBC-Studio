import cls from './Tech.module.scss'
import { useState } from 'react'
import BetweenTitle from '../BetweenTitle/BetweenTitle'

const Tech = () => {

    const [checkbox, setCheckbox] = useState('')

    return (
        <section className={cls.tech}>
            <BetweenTitle content="Technologies & Tools" color="white"/>
            <ul>
                <li>
                    <span 
                        className={cls.checkbox} 
                        onClick={() => setCheckbox('frontend')} 
                    >
                        {checkbox === 'frontend' ? (
                            <span className={cls.checkCircle}></span>
                        ) : null}
                    </span> 
                    Frontend
                </li>
                <li>
                    <span 
                        className={cls.checkbox} 
                        onClick={() => setCheckbox('design')} 
                    >
                        {checkbox === 'design' ? (
                            <span className={cls.checkCircle}></span>
                        ) : null}
                    </span> 
                    Ux & Ui
                </li>
                <li>
                    <span 
                        className={cls.checkbox} 
                        onClick={() => setCheckbox('video')} 
                    >
                        {checkbox === 'video' ? (
                            <span className={cls.checkCircle}></span>
                        ) : null}
                    </span> 
                    VideoEditing
                </li>
                <li>
                    <span 
                        className={cls.checkbox} 
                        onClick={() => setCheckbox('backend')} 
                    >
                        {checkbox === 'backend' ? (
                            <span className={cls.checkCircle}></span>
                        ) : null}
                    </span> 
                    Backend
                </li>
                <li>
                    <span 
                        className={cls.checkbox} 
                        onClick={() => setCheckbox('marketing')}
                    >
                        {checkbox === 'marketing' ? (
                            <span className={cls.checkCircle}></span>
                        ) : null}
                    </span> 
                    Marketing
                </li>
            </ul>
            <div className={cls.grid}>
                {/* Design */}
                <div className={cls.design} id={cls.design1}><img src="/img/figma.png" alt="figma"/></div>
                <div className={cls.design} id={cls.design2}></div> 
                <div className={cls.design} id={cls.design3}></div>
                <div className={cls.design} id={cls.design4}></div>
                <div className={cls.design} id={cls.design5}></div>
                <div className={cls.design} id={cls.design6}></div>
                <div className={cls.design} id={cls.design7}></div>
                <div className={cls.design} id={cls.design8}></div>
                <div className={cls.design} id={cls.design9}></div>
                <div className={cls.design} id={cls.design10}></div>
                {/* VideoEditing */}
                <div className={cls.edit} id={cls.edit1}><img src="/img/premierepro.png" alt="premiere-pro" /></div>
                <div className={cls.edit} id={cls.edit2}></div>
                <div className={cls.edit} id={cls.edit3}></div>
                <div className={cls.edit} id={cls.edit4}></div>
                <div className={cls.edit} id={cls.edit5}></div>
                <div className={cls.edit} id={cls.edit6}></div>
                <div className={cls.edit} id={cls.edit7}></div>
                <div className={cls.edit} id={cls.edit8}></div>
                <div className={cls.edit} id={cls.edit9}></div>
                <div className={cls.edit} id={cls.edit10}></div>
                <div className={cls.edit} id={cls.edit11}></div>
                <div className={cls.edit} id={cls.edit12}></div>
                {/* VideoEditing2 */}
                <div className={cls.video} id={cls.video1}><img src="/img/webstorm.png" alt="webstorm" /></div>
                <div className={cls.video} id={cls.video2}></div>
                <div className={cls.video} id={cls.video3}></div>
                <div className={cls.video} id={cls.video4}></div>
                <div className={cls.video} id={cls.video5}></div>
                <div className={cls.video} id={cls.video6}></div>
                <div className={cls.video} id={cls.video7}></div>
                <div className={cls.video} id={cls.video8}></div>
                <div className={cls.video} id={cls.video9}></div>
                <div className={cls.video} id={cls.video10}></div>
                <div className={cls.video} id={cls.video11}></div>
                <div className={cls.video} id={cls.video12}></div>
                <div className={cls.video} id={cls.video13}></div>
                <div className={cls.video} id={cls.video14}></div>
                <div className={cls.video} id={cls.video15}></div>
                <div className={cls.video} id={cls.video16}></div>
                {/* Frontend */}
                <div className={cls.frontend} id={cls.frontend1}></div>
                <div className={cls.frontend} id={cls.frontend2}></div>
                <div className={cls.frontend} id={cls.frontend3}></div>
                <div className={cls.frontend} id={cls.frontend4}></div>
                <div className={cls.frontend} id={cls.frontend5}></div>
                <div className={cls.frontend} id={cls.frontend6}></div>
                <div className={cls.frontend} id={cls.frontend7}></div>
                <div className={cls.frontend} id={cls.frontend8}></div>
                <div className={cls.frontend} id={cls.frontend9}></div>
                <div className={cls.frontend} id={cls.frontend10}></div>
                <div className={cls.frontend} id={cls.frontend11}></div>
                <div className={cls.frontend} id={cls.frontend12}></div>
                {/* Frontend2 */}
                <div className={cls.front} id={cls.front1}></div>
                <div className={cls.front} id={cls.front2}></div>
                <div className={cls.front} id={cls.front3}></div>
                <div className={cls.front} id={cls.front4}></div>
                <div className={cls.front} id={cls.front5}></div>
                <div className={cls.front} id={cls.front6}></div>
                <div className={cls.front} id={cls.front7}></div>
                <div className={cls.front} id={cls.front8}></div>
                <div className={cls.front} id={cls.front9}></div>
                <div className={cls.front} id={cls.front10}></div>
                <div className={cls.front} id={cls.front11}></div>
                <div className={cls.front} id={cls.front12}></div>
                {/* Backend */}
                <div className={cls.backend} id={cls.backend1}></div>
                <div className={cls.backend} id={cls.backend2}></div>
                <div className={cls.backend} id={cls.backend3}></div>
                <div className={cls.backend} id={cls.backend4}></div>
                <div className={cls.backend} id={cls.backend5}></div>
                <div className={cls.backend} id={cls.backend6}></div>
                <div className={cls.backend} id={cls.backend7}></div>
                <div className={cls.backend} id={cls.backend8}></div>
                <div className={cls.backend} id={cls.backend9}></div>
                <div className={cls.backend} id={cls.backend10}></div>
                <div className={cls.backend} id={cls.backend11}></div>
                <div className={cls.backend} id={cls.backend12}></div>
                {/* Marketing */}
                <div className={cls.marketing} id={cls.marketing1}></div>
                <div className={cls.marketing} id={cls.marketing2}></div>
                <div className={cls.marketing} id={cls.marketing3}></div>
                <div className={cls.marketing} id={cls.marketing4}></div>
                <div className={cls.marketing} id={cls.marketing5}></div>
                <div className={cls.marketing} id={cls.marketing6}></div>
                <div className={cls.marketing} id={cls.marketing7}></div>
                <div className={cls.marketing} id={cls.marketing8}></div>
                <div className={cls.marketing} id={cls.marketing9}></div>
                <div className={cls.marketing} id={cls.marketing10}></div>
                <div className={cls.marketing} id={cls.marketing11}></div>
                <div className={cls.marketing} id={cls.marketing12}></div>
            </div>
        </section>
    )
}

export default Tech